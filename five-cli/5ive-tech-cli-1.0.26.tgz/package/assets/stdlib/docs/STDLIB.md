# 5IVE Standard Library (Bundled v1)

The compiler provides stdlib modules from a bundled source registry.
Local `src/std` files are ignored in bundled mode.

## Included modules

1. `std::prelude`
2. `std::builtins`
3. `std::interfaces::spl_token`
4. `std::interfaces::system_program`

## Import style (explicit)

```v
use std::builtins::{now_seconds};
use std::interfaces::spl_token;
use std::interfaces::system_program;
```

Also supported:

```v
use std::builtins;
let now = builtins::now_seconds();
```

Documented import forms:

1. `use std::builtins::{now_seconds};` then call `now_seconds()`
2. `use std::builtins;` then call `builtins::now_seconds()`
3. `use std::interfaces::spl_token;` to load the SPL Token interface module
4. `use std::interfaces::system_program;` to load the System Program interface module

Use these forms as canonical stdlib module paths.

## Migration path

Current mode is bundled/inlined stdlib.
Future mode may support external dependency linkage.

## Troubleshooting

If your globally installed `5ive` binary behaves differently from the local monorepo code, run the local CLI dist directly:

```bash
node ./five-cli/dist/index.js <command>
```
